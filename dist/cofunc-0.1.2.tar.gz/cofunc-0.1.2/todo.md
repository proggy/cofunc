# To Do

- like "mean", implement functions like "min", "max", "sum" that accept
  coFunc objects
- ease plotting data of coFunc objects?
- integrate the function
- provide standard coFunc objects like "Sin", "Cos", "Tan" etc.
- nD coFunc objects?
- add math to coFunc2d


# Possible Future Extensions

- R->R, C->C, N->N, Z->Z? Different data types?
- different dimensions? Mappings like R->R^3? R^2->R^3?
- xlabel, ylabel
- ease plotting the function
- integrals
- cut/trim the function (get a certain part of it) (also in y-direction)
- yerr, xerr? make a new class for that?
- also method to return coFunc(x, yerr), coFunc(x, xerr)
