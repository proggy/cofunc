# Change Log

## v0.1.2

- prepare package structure for PyPI release
- remove dependency on bundle (could use SuperDict in the future, but not really important)


## v0.1.1

- make Python-3-compatible
- update contact email
- introduce version attribute
- use bundle only if it is installed
