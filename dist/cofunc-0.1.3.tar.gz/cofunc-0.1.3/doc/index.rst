.. cofunc documentation master file, created by
   sphinx-quickstart on Tue Jun 10 11:07:52 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

cofunc
######

.. toctree::
   :maxdepth: 2

.. automodule:: cofunc


Classes
=======

.. autoclass:: coFunc
.. autoclass:: coFunc2d


Functions
=========

.. autofunction:: mean
.. autofunction:: var
.. autofunction:: intersection
.. autofunction:: combine


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

